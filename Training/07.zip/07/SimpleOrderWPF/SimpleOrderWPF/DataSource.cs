﻿using System.Collections.Generic;
// -----------------------------------------------------------------------
// <copyright file="DataSource.cs" company="Microsoft">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------
using BusinessLogic;

namespace SimpleOrderWPF
{

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public class SimpleOrderDataSource
    {
        SimpleOrderEntities _entities = new SimpleOrderEntities();
        
        public IList<SalesOrder> GetOrders()
        {
            return new List<SalesOrder>(_entities.SalesOrders);
        }

        public IList<Customer> GetCustomers()
        {
            return new List<Customer>(_entities.Customers);
        }

        public IList<OrderLine> GetOrderLines()
        {
            return new List<OrderLine>(_entities.OrderLines);
        }

    }
}
