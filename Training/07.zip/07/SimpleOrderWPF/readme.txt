1. Restore KS2010008.bak to local SQLServer (DB name KS201008)
2. Run Excutable\KS201008.exe