﻿using System;
using System.Threading;

namespace SimpleWebPage
{
    public partial class WebApp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        [System.Web.Services.WebMethod]
        public static string GetCurrentTime(string name, int i)
        {
            return i.ToString() + "Hello " + name + Environment.NewLine + "The Current Time is: "
                + DateTime.Now.ToString();
        }

        [System.Web.Services.WebMethod]
        public static double Calc(int a, int b, int op)
        {
            double res = 0.0;
            if (op == 1)
            {
                res = Sum(a, b);
            }
            else if (op == 2)
            {
                res = Diff(a, b);
            }
            else if (op == 3)
            {
                res = Product(a, b);
            }

            Thread.Sleep(3000);   
            return res;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int alpha = int.Parse(TextBox1.Text.Trim());
            int beta = int.Parse(TextBox2.Text.Trim());

            if (RadioButton1.Checked)
            {
                TextBox3.Text = Sum(alpha, beta).ToString("F4");
            }
            else if (RadioButton2.Checked)
            {
                TextBox3.Text = Diff(alpha, beta).ToString("F4");
            }
            else if (RadioButton3.Checked)
            {
                TextBox3.Text = Product(alpha, beta).ToString("F4");
            }
            else
                TextBox3.Text = "Select method";

            Thread.Sleep(3000);            
        }

       

        private static double Sum(int a, int b)
        {
            double ans = 0.0;
            ans = a + b;
            return ans;
        }

        private static double Diff(int a, int b)
        {
            double ans = 0.0;
            ans = a - b;
            return ans;
        }

        private static double Product(int a, int b)
        {
            double ans = 0.0;
            ans = a * b;
            return ans;
        }
    }
}