﻿using System;
using System.Windows.Forms;
using mshtml;

namespace WebPageAutomation
{
    public partial class Form1 : Form
    {
        private bool _bAuto = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.webBrowser1.WebBrowserShortcutsEnabled = false;
            this.webBrowser1.IsWebBrowserContextMenuEnabled = true;
            this.webBrowser1.Navigate(textBox1.Text);
            
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (!_bAuto) return;

            if (this.webBrowser1.ReadyState != WebBrowserReadyState.Complete)
                return;

            if (e.Url.AbsoluteUri == textBox1.Text)
            {
                HTMLDocument doc = (HTMLDocument)this.webBrowser1.Document.DomDocument;
                IHTMLElementCollection elements = (IHTMLElementCollection)doc.getElementsByTagName("input");
                for (int i = 0; i < elements.length; i++)
                {
                    HTMLInputElement input = (HTMLInputElement)elements.item(i); 
                    if (input.id == "TextBox1")
                    {
                        input.setAttribute("value", "5");
                       // input.value = "5";
                    }
                    else if (input.id == "TextBox2")
                    {
                        input.setAttribute("value", "7");
                       // input.value = "7";
                    }
                    else if (input.id == "RadioButton1")
                    {
                        ((HTMLOptionButtonElement)input).setAttribute("checked", true);
                    }

                    HTMLInputElement btn = (HTMLInputElement)doc.getElementById("Button1");
                    btn.click();
                }                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _bAuto = true;
            this.webBrowser1.Navigate(textBox1.Text);
           
        }

     }
}
