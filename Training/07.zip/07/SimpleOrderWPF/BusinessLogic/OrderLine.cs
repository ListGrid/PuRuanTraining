﻿// -----------------------------------------------------------------------
// <copyright file="OrderLine.cs" company="Microsoft">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace BusinessLogic
{
    using System.Collections.Generic;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public partial class OrderLine
    {
        private IDictionary<string, bool> m_Changing = new Dictionary<string, bool>();
        protected bool IsChanging(string propertyName)
        {
            if (m_Changing.ContainsKey(propertyName))
            {
                return m_Changing[propertyName];
            }
            else
            {
                return false;
            }

        }
        
        partial void OnPriceChanging(decimal value)
        {
            m_Changing["Price"] = true;
        }
        
        partial void OnQuantityChanging(int value)
        {
            m_Changing["Quantity"] = true;
        }

        partial void OnLineTotalChanging(decimal value)
        {
            m_Changing["LineTotal"] = true;
        }
        
        partial void OnPriceChanged()
        {
            RecalcLineTotal();
            m_Changing["Price"] = false;
        }

        partial void OnQuantityChanged()
        {
            RecalcLineTotal();
            m_Changing["Quantity"] = false;
        }
        
        partial void OnLineTotalChanged()
        {
            // recalculate price
            if (!IsChanging("Price") &&
                !IsChanging("Quantity") && Quantity != 0)
            {
                Price = LineTotal / Quantity;               
            }
            if (this.SalesOrder != null)
                this.SalesOrder.CalcDocTotal();

            m_Changing["LineTotal"] = false;
        }
        
        protected void RecalcLineTotal()
        {
            if (!IsChanging("LineTotal"))
            {
                LineTotal = Quantity * Price;
            }
        }  
    }
      
}
