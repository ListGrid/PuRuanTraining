﻿using System;
using System.Web.Mvc;
using SimpleMVC.Models;

namespace SimpleMVC.Controllers
{
    public class CustomerController : Controller
    {
        ModelService _modelService = new ModelService();
        public ActionResult WebGridInit(int page = 1, string sort = "custid", string sortDir = "ASC")
        {
            const int pageSize = 3;
            var totalRows = _modelService.CountCustomer();

            bool Dir = sortDir.Equals("desc", StringComparison.CurrentCultureIgnoreCase) ? true : false;

            var customer = _modelService.GetCustomerPage(page, pageSize, sort, Dir);
            var data = new PagedCustomerModel()
            {
                TotalRows = totalRows,
                PageSize = pageSize,
                Customer = customer
            };
            return View(data);
        }

        [HttpPut]
        public JsonResult UpdateRecord(int id, string name, string address, string contactno)
        {
            bool result = false;
            try
            {
                result = _modelService.UpdateCustomer(id, name, address, contactno);

            }
            catch (Exception ex)
            {
            }
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveRecord(string name, string address, string contactno)
        {
            bool result = false;
            try
            {
                result = _modelService.SaveCustomer(name, address, contactno);

            }
            catch (Exception ex)
            {
            }
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }

        [HttpDelete]
        public JsonResult DeleteRecord(int id)
        {
            bool result = false;
            try
            {
                result = _modelService.DeleteCustomer(id);

            }
            catch (Exception ex)
            {
            }
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }
    }
}
