﻿using System.Collections.Generic;
using System.Windows;
using BusinessLogic;

namespace SimpleOrderWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SimpleOrderEntities _entities;
        List<SalesOrder> _orders;
        int _index = 0;

        public MainWindow()
        {
            InitializeComponent();
            _entities = new SimpleOrderEntities();
            _orders = new List<SalesOrder>(_entities.SalesOrders);

            this.comboBox1.ItemsSource = _entities.Customers;
            
            if (_orders.Count > 0)
                this.DataContext = _orders[0];
            

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if (_index > 0)
            {
                _index--;
                this.DataContext = _orders[_index];
            }
            
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            if (_index < _orders.Count - 1)
            {
                _index++;
                this.DataContext = _orders[_index];
            }
        }
    }
}
