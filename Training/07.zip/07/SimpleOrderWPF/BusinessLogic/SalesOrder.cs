﻿// -----------------------------------------------------------------------
// <copyright file="Order.cs" company="Microsoft">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace BusinessLogic
{

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public partial class SalesOrder
    {
        public SalesOrder()
        {
            this.OrderLines.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(OrderLines_CollectionChanged);
        }

        void OrderLines_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems != null)
            {
                foreach (OrderLine line in e.NewItems)
                {
                    line.SalesOrder = this;
                }
            }
            
        }

        public void CalcDocTotal()
        {
            decimal total = 0.0m;
            foreach (OrderLine line in this.OrderLines)
            {
                total += line.LineTotal;
            }
            this.DocTotal = total;
        }
    }
}
